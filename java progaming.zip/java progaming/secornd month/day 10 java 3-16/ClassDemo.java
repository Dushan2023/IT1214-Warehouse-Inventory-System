
import java.util.*;

class Subject{
	String name;
	int marks;
	
	
	
	Subject(String name,int marks){
		this.name=name;
		this.marks=marks;
	}
}

	
	

class Student{
	String name;
	String regNo;
	Subject sub1;//=new Subject(); 
	
	
	
	Student(String name,String regNo,String SubName,int marks){
	this.name=name;
	this.regNo=regNo;
	sub1=new Subject(SubName,marks);
	//sub1.=new Subject();
	//sub1.name=SubName;
	//sub1.marks=marks;
	
	System.out.println("Name= " +name+"regNo= " +regNo+" "+sub1.marks+" for "+sub1.name);
		
	}
}
	
	
	
	
	
class ClassDemo{
	public static void main(String ar[]){
		Scanner sc=new Scanner(System.in);
		
		System.out.println("Enter the student name,Reg#,subject Name,and marks");
		
		Student s1=new Student(sc.nextLine(),sc.nextLine(),sc.nextLine(),sc.nextInt());
		Student s2=new Student("Bob","2020/IT/002","Science",85);
	}
}




