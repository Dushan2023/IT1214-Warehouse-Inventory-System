class Point{
	int x;
	int y;
	Point(int x,int y){
		this.x=x;
		this.y=y;
	}
}
class Location{
	String name;
	Point p;
	Location (String name,int x,int y){
		this.name=name;
		p=new Point(x,y);
	}
	
	void describe(){
		System.out.println("location name is "+name+" coordinate x and y are "+p.x
		+","+p.y);
	}
}

class LocationDemo{
	public static void main(String arg[]){
		
	/*int a[3];
		
		a[0]=1;
		a[1]=2;
		a[2]=3;*/
		
		
		Location l[]= new Location[3];
		l[0]=new Location("Origin",0,0);
		l[1]=new Location("point 1",2,3);
		l[2]=new Location("point 2",5,6);
		
		
		l[0].describe();
		l[1].describe();
		l[2].describe();
		
	}
}