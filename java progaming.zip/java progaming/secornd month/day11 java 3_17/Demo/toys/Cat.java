package demo.pets;

public class Cat{
	public cat(){
		System.out.println("meou");
	}
}