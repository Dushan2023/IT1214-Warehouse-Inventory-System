package demo.toys;
class Doll{
	system.out.println("I am doll"); 
}

class Ball{
	Ball(){
		System.out.println("I am ball");
	}
}