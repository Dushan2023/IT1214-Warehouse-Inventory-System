package demo;

import demo.pets.cat;

class App{
	public static void main(Sting ar[]){
		system.out.println(printing from app");
		Cat c=new Cat();
	}
}