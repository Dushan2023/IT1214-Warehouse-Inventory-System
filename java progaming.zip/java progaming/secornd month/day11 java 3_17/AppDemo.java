class User{
	String username;
	String password;
	
	
	User(String username,String password){
		this.password=password;
		this.username=username;
		
		System.out.println("Printing in super class constructor -Username is "+username+"  ,Password is - "+password);
	}
}

class Student extends User{
	 String regNo;
	
	Student(String uname,String pass,String rNo){
		
		/*super.regNo=regNo;
		super.password=password;*/
		
		super(uname,pass);
		this.regNo=rNo;
		super.username="MYNAME";
		password="NEWPASSWORD";
		System.out.println("Printing in sub class constructor -Username is "+uname+"  ,Password is - "+pass+" Registration number is "+rNo);
		
	}
}

class AppDemo{
	public static void main(String ar[]){
		
		Student s1=new Student("adem","abc123","2023/ict/001");
		Student s2=new Student("Dushan","abc124","2023/ict/002");
	}
}