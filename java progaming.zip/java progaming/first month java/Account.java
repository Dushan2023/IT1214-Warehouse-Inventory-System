class Account{
	String account_holder;
	int account_number;
	static double interest_rate=2.5;
	private double balance; // only within the class
	
	Account(String holder_name,int account_number,double bal){
		this.account_holder=holder_name;
		this.account_number=account_number;
		balance=bal;
	}
	
	public void deposit(double amount){ //setter method
	
		balance = balance + amount; //balance+=amount;
		System.out.println("Deposit---> \n Holder Name:"+account_holder+" Account Number:"+account_number+" Deposited Amount:"+amount+" Current Balance:"+balance);
	}
	
	public void withdraw(double amount){
		if(balance>=amount){
			balance = balance - amount; //balance-=amount;
			System.out.println("Withdraw------> \n Holder Name:"+account_holder+" Account Number:"+account_number+" Withdrawn Amount:"+amount+" Current Balance:"+balance);
		}else{
			System.out.println("Low Balance!");
		}
				
	}
	
	void printDetails(){
		System.out.println("Holder Name:"+account_holder+" Account Number:"+account_number+" Balance:"+balance+" Interest Rate:"+interest_rate);
	}
}

class BankApp{
	public static void main(String ar[]){
		Account a1=new Account("S.Kirushath",123456879,1000); 
		Account a2=new Account("K.Ahil",123456891,2000); 
		//Account(holder Name, account number, opening balance)
		/*
		a1.printDetails();
		a1.deposit(2500);
		a1.withdraw(10000);
		a1.withdraw(1500);
		a1.printDetails();
		*/
		System.out.println("----Priting Interest Rates-----");
		a1.printDetails();
		a2.printDetails();
		
		a2.interest_rate=5.5;
		
		a1.printDetails();
		a2.printDetails();
	}
}