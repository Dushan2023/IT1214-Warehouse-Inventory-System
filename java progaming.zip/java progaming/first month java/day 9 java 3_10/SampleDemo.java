class Sample{
	static int count=0;
	final int price;
	String name;
	
	Sample(){
		count++;//Count=count+1
		price=10;
		System.out.println("New Sample Object Craet.value of count is " +count);
	}
	
	
	Sample(String name){
		count++;
		this.name=name;
		price=20;
		System.out.println("New Sample Object Craet with name="+name+"Value of count is "+count);
	}
	
	Sample(String name,int price){
		count++;
		this.name=name;
		this.price=price;
		System.out.println("New Sample object Crated with name"+name+",price Rs."+price+".Value of Count is"+count);
		
	}
	
	void display(){
		
		System.out.println("Sample name" +name+ ",price Rs." +price+ ",count is " +count);
		
	}
	
	
}

class SampleDemo{
	public static void main (String ar[]){
		Sample Sample1=new Sample(); //Creating an object with no argument
		Sample Sample2=new Sample("Water");//Create an object with a name		
		Sample Sample3=new Sample("Soil",50);//Craeting an object with a name
		
		Sample1.display();
		Sample2.display();
		Sample3.display();
	}
	
}