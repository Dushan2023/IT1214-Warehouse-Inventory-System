


import java.util.*;




class InputDemo{
	public static void main(String arg[]){
		
		Scanner sc=new Scanner(System.in);
		
		int a=0;
		float avarage;
		System.out.println("The value of a is  "+a);
		
		
		
	    for(int i=0;i<10;i++){
			
		System.out.println("Enter the value for a:");
		avarage=(a+a)/10;
		a=sc.nextInt();
	}
		System.out.println("The value of a is "+a);
		System.out.println("The value of avarage is "+avarage);
	}
}


//write the program to fint the avarage value of 10 integer from user promt