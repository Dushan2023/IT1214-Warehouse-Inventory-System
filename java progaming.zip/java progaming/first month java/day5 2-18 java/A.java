class A{
	int x;
	int y;
	int z;
	
	A(){
		x=5;
		y=10;
		z=20;
		System.out.println("----print defult cuntruction A()");
	}
	A(int p1,int p2,intp3){
		System.out.println("--print from constrrustopr a(int,int,int)---");
		x=p1;
		y=p2;
		z=p3;
	}
	void initialize(){
		x=1;
		y=2;
		z=3;
	}
	}
