class B{
	public static void main(String arg[]){
		
		
		System.out.println("print from B");
		A obj1=new A();
		
		
		System.out.println("Just created an object of A named obj1 using default constructor");
		
		System.out.println("value of x of obj1="+ obj1.x);
		System.out.println("***Assining 10 to obj1");
		obj1.x=10;
		obj1.initialize();
		System.out.println("*** value of  x of obj1="+ obj1.x);
		System.out.println("value of y of obj1="+  obj1.y);
		System.out.println("value of z of obj1="+obj1.z);
		
		A obj2=new A();
		
		System.out.println("Just created an object of A named obj1 using default constructor");
		
		System.out.println("value of x of obj2="+ obj2.x);
		System.out.println("***Assining 40 to obj2");
		obj1.x=40;
		System.out.println("*** value of  x of obj2="+ obj2.x);
		System.out.println("*** value of  x of obj2="+ obj2.x);
		System.out.println("value of y of obj2="+  obj2.y);
		System.out.println("value of z of obj2="+obj2.z);
		
	}
}