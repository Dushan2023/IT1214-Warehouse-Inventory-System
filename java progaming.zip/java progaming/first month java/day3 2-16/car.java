class Car{
	String model;
	int cc;//engine cpacity
	String color;
	
	void printDetails(){
		
		System.out.println("car Model is :"+model+",engine capacity is"+cc+", color is "+color);
	}
	
}