class Person{
	
	int age=10;
	String name="Adam";
	String address="World";
	
	void printDetails(){
		
		System.out.println("Name is "+ name);
		System.out.println("addres is " + address);
		
		
	}
	
	public static void main(String arg[]){
		
		System.out.println("Hi");
		Person p1=new Person();
		
		//creatin an instent of Person
		p1.printDetails();
	}
	
	
}