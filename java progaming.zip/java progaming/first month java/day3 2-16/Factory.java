class Factory{
	public static void main (String args []){
		//Creating car object
		Car c1=new Car();
		//assing values to its variables
		c1.model="yasis";
		c1.cc=1000;
		c1.color="white";
		
		System.out.println("created c1 as an instanmce of car");
		System.out.println("c1 Model:"+c1.model+",engine capacity is"+c1.cc+", color is "+c1.color);
		
	}
}