class Human{
	
	String name;
	String gender;
	String nationality;
	byte age;
	String adderss;
	
 
	Human(){
		nationality="Sri Lanka";
		
	}
	
	Human(String na){
		name=na;
	}
	Human (String na,int age ,String gen,String nat,String add){
		name=na;
		gender=gen;
		nationality=nat;
		adderss=add;
	}
	
	void printDetails(){
		System.out.println("Name:"+name+"\n Gender:"+gender+"\n Nationality:"+nationality+"\n age:"+age+"\n adderss:"+adderss);
		
	}
	
}