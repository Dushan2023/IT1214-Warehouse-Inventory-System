class Users{
	public static void main (String ar[]){
		
		Human h1=new Human();
		h1.name="adam";
		h1.age=20;
		h1.nationality="indian";
		h1.adderss="India";
		
		Human h2=new Human();
		
		h1.printDetails();
		h2.printDetails();
		
		Human h3=new Human ("Charle",30,"male","pakistani","pakistan");
		
		h3.printDetails();
	}
}