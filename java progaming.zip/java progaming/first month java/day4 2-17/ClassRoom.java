class ClassRoom{
	public static void main(String args []){
	
		Student s1=new Student();
		Student s2=new Student();
		Student s3=new Student();
		
		s1.index=001;
		s1.name="Admin";
		s1.marks=90;
		
		s2.index=002;
		s2.name="Dushan";
		s2.marks=95;
		
		s3.index=003;
		s3.name="dave";
		s3.marks=85;
		
		s1.printDetails();
		s2.printDetails();
		s3.printDetails();
	}
}