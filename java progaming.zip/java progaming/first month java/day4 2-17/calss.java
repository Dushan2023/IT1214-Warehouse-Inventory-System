class ClassRoom{
	public static void main(){
	
		Student s1=new Student();
		Student s2=new Student();
		Student s3=new Student();
		
		
		s1.name="Admin";
		s1.marks=90;
		s1.printDetails();
		s2.printDetails();
		s3.printDetails();
	}
}