class Student{
	
	String name;
	int marks;
	int index;
	
	void printDetails(){
		//just print the details of a student
		//you need to emplements of a student
		System.out.println("index=" + index);
		System.out.println(" name=" + name);
		System.out.println(" marks=" + marks);
	}
}