// one line code

/*in java tis is a reference to the current object-the object 
whose mwtode or constructor is being called*/

class Person{
	String name;
	int age;
	

	
	Person(String name,int age){
		this.name=name;  //this refers to current object.
		                 
		this.age=age;
		/*when a paramiter has the same name as an instanse variable this is
        differentiate them*/
		/*without this java assume you are referring to thge parameter only*/
		/*commonly usd in constructors and stter methods*/
		/*cannote be use static metode*/
	}	
	
	void display(){
		System.out.println("Name="+name+"age="+age);
	}
	
}

	


class PersonDemoDetails{
	public static void main(String ar[]){
		
		
			
			Person p1=new Person("Infa",20);
			Person p2=new Person("Rikaza",50);
			
			p1.display();
			p2.display();
	}
}
