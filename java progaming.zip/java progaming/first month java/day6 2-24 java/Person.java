class Person{
	String name;
	int age;
	
	//counstractor
	
	Person(String na,int ag){
		name=na;
		age=ag;
	}
}

	

// new class file
class PersonDemo{
	public static void main(String ar[]){
		
			System.out.println("--This is Main Class PersonDemo--");
			
			Person p1=new Person("Infa",20);
			Person p2=new Person("Rikaza",50);
			
			System.out.println("Created Tow Person object p1 and p2");
			
			System.out.println("Name of the  Person p1 is"+ p1.name + "  Age is the person " + p1.age);
			System.out.println("Name of the Person p2 is"+ p2.name + "  Age is the person  " + p2.age);
	}
}
