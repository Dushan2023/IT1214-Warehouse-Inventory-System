class Person{
	String name;
	
}
class PersonDemo{
	public static void main(String ar[]){
		
	}
}