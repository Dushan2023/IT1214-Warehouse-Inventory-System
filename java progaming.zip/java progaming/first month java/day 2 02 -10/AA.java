class A{
	static void printHi(){
		System.out.println("Hi form printHi");
	}
	static void add(int a,int b){
		System.out.println(a+"+"+b+"="+(a+b));
	}
	public static void main (String ar[]){
		System.out.println("Hello form A");
		printHi();
		
		add(5,3);
		int a=2;
		int b=7;
		add(a,b);
		
		
		
		
	}
}