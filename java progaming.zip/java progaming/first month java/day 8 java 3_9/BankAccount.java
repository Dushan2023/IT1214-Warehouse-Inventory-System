//file name  BankAccountDemo.java
class BankAccount{
	static int ir;//interst_rate	
	int account_number;
	
	BankAccount(){
		
		System.out.println("Creating an Account");
	}	
		
	BankAccount(int acc){
		
		account_number=acc;
	}
	
	
	void printDetail(){

	
		
		System.out.println("Account Number is "+account_number);
		System.out.println("Instest Rate is "+ir);
	}
}

class BankAccountDemo{
	public static void main(String arg[]){
		
		
		BankAccount ac1=new BankAccount(123456789);
		ac1.ir=3;
		ac1.printDetail();
		
		
		BankAccount ac2=new BankAccount(56789);
		ac2.ir=0;
		ac2.printDetail();
		
		BankAccount ac3=new BankAccount();
		ac3.printDetail();
	}
}

