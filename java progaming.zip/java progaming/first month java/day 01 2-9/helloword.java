class Hello{
	//this is the main method/ function
	public static void main (String args[]){
		System.out.println("Helow!my Name is Dushan");
		// no new line. only type "print"
		System.out.print(" Dushan");
		System.out.println(" Eranda");
		
		for(int i=0;i<args.length;i++){
			System.out.println(i +"th Argument is : "+ args[i] );
		}
}
}