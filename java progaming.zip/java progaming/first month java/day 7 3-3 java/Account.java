class Account{
	
	String account_holder;
	int account_number;
	float interest_rate;
	private float balance;
	
	
	Account(String account_holder ,int account_number,float balance ){
		
		this.account_holder=account_holder;
		this.account_number=account_number;
		this.balance=balance;
		
} 

	public void deposit(float amount){
		
		balance=balance+amount;
		
		System.out.println("Deposit--->\n Holder Name:"+account_holder+"Acount_number:"+account_number+
		"Deposited Amount:"+amount+"Current Balance:"+balance);
		
		}
		
	public void withdraw(float amount){
		//todo
	}

	void display(){
		System.out.println("holde name=" + account_holder);
		System.out.println("Account numbe=" + account_number);
		System.out.println("opening balance=" + balance);
		System.out.println("-----------new---------");
	}
	}
	

class BankApp{
	public static void main(String ar[]){
		Account a1=new Account("s kirushanth",123456789,1000);
		//Account(holde name,Account number,opening balance)
	
		
		
		a1.display();
		a1.deposit(2500);
		a1.display();
		
	
	}
}