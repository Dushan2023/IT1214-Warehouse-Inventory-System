class Account{
	String account_holder;
	int account_number;
	float interest_rate;
	private float balance;
	
	Account(String holder_name,int account_number,float bal){
		this.account_holder=holder_name;
		this.account_number=account_number;
		balance=bal;
	}
	
	public void deposit(float amount){ //setter method
	
		balance = balance + amount; //balance+=amount;
		System.out.println("Deposit---> \n Holder Name:"+account_holder+" Account Number:"+account_number+" Deposited Amount:"+amount+" Current Balance:"+balance);
	}
	
	public void withdraw(float amount){
		if(balance>=amount){
			balance=balance-amount;
			System.out.println("withdraw Ac name="+account_holder);
			System.out.println("withdraw Ac numbe="+account_number);
			System.out.println("withdraw Ac amount="+amount);
			System.out.println("withdraw Ac balence="+balance);
		}else{
			System.out.print("withdraw balence less");
			
		}
	}
	
	void printDetails(){
		System.out.println("Holder Name:"+account_holder+" Account Number:"+account_number+" Balance:"+balance+" Interest Rate:"+interest_rate);
	}
}

class BankApp{
	public static void main(String ar[]){
		Account a1=new Account("S.Kirushath",123456879,1000); 
		//Account(holder Name, account number, opening balance)
		a1.printDetails();
		a1.deposit(2500);
		a1.printDetails();
		
	}
}