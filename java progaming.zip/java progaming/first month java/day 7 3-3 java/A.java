class A{
	String name;
	static String address;
	
	A(String a, String b){
		this.name=a;
		this.address=b;
	}
	
	void printDetail(){
		System.out.println(" Name = "+name + " Address = "+address);
	}
	
}

class DemoA{
	public static void main(String ar[]){
		A o1=new A("Adam","Earth");
		o1.printDetail();
		A o2=new A("Eve","Earth");
		o2.printDetail();
		A o3=new A("Elon","Mars");
		o3.printDetail();
		o1.address="World";
		System.out.println("-------------------");
		o1.printDetail();
		o2.printDetail();
		o3.printDetail();
		
	}
}